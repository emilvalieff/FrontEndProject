const loginFormContainer = document.querySelector('.login-form-container');
const registerFormContainer = document.querySelector('.register-form-container');
const registerLink = document.getElementById('register-link');
const loginLink = document.getElementById('login-link');
const backgrounds = document.querySelectorAll('.background-image');
const genderSelect = document.querySelector('.auth-form select');

let currentBackground = 0;

// Login/Register geçişi
registerLink.addEventListener('click', (e) => {
  e.preventDefault();
  loginFormContainer.style.transform = "rotateY(180deg)"; // Login'i 180 derece döndür
  registerFormContainer.style.transform = "rotateY(0deg)"; // Register'i normale döndür
  registerFormContainer.classList.add('active');
  loginFormContainer.classList.remove('active');
});

loginLink.addEventListener('click', (e) => {
  e.preventDefault();
  loginFormContainer.style.transform = "rotateY(0deg)"; // Login'i normale döndür
  registerFormContainer.style.transform = "rotateY(-180deg)"; // Register'i 180 derece döndür
  loginFormContainer.classList.add('active');
  registerFormContainer.classList.remove('active');
});

// Arka plan geçişi (2.5 saniyelik hız)
function slideBackgrounds() {
  backgrounds.forEach((bg, index) => {
    if (index === currentBackground) {
      bg.style.left = "0%";
    } else if (index === (currentBackground + 1) % backgrounds.length) {
      bg.style.left = "100%";
    } else {
      bg.style.left = "-100%";
    }
  });

  currentBackground = (currentBackground + 1) % backgrounds.length;
}

// Slider interval (geçiş hızını 2.5 saniye yapma)
setInterval(slideBackgrounds, 2500); // 2.5 saniyede bir geçiş

// İlk fotoğrafın anında görünmesi
document.addEventListener("DOMContentLoaded", function() {
  setTimeout(() => slideBackgrounds(), 500); // İlk geçişi 0.5 saniye sonra yap
});

// Gender seçim kutusuna dinamik etkileşim ekleme
genderSelect.addEventListener('change', () => {
  if (genderSelect.value) {
    genderSelect.style.color = "#333"; // Kullanıcı seçim yaptıktan sonra yazı rengi değişir
  } else {
    genderSelect.style.color = "#888"; // Varsayılan renk (seçim yapılmamışsa)
  }
});

// Sayfa yüklendiğinde varsayılan renk ayarı
document.addEventListener('DOMContentLoaded', () => {
  if (!genderSelect.value) {
    genderSelect.style.color = "#888"; // Varsayılan renk ayarı
  }
});
